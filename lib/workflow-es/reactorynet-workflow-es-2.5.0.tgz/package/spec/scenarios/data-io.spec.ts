import { WorkflowHost, WorkflowBuilder, WorkflowStatus, WorkflowBase, StepBody, StepExecutionContext, ExecutionResult, WorkflowInstance, configureWorkflow, ConsoleLogger } from "../../src";
import { MemoryPersistenceProvider } from "../../src/services/memory-persistence-provider";
import { spinWait } from "../helpers/spin-wait";

 describe("data io", () => {

     class AddNumbers extends StepBody {    
         public number1: number;
         public number2: number;
         public result: number;

         public run(context: StepExecutionContext): Promise<ExecutionResult> {
             this.result = this.number1 + this.number2;
             return ExecutionResult.next();
         }
     }    

     class MyDataClass {
         public value1: number;
         public value2: number;
         public value3: number;
     }

     class Data_Workflow implements WorkflowBase<MyDataClass> {    
         public id: string = "data-workflow";
         public version: number = 1;

         public build(builder: WorkflowBuilder<MyDataClass>) {        
             builder
             .startWith(AddNumbers)
                 .input((step, data) => step.number1 = data.value1)
                 .input((step, data) => step.number2 = data.value2)
                 .output((step, data) => data.value3 = step.result)
         }
     }

     let workflowId: string | null = null;
     let instance: WorkflowInstance | null = null;
     let persistence = new MemoryPersistenceProvider();
     let config = configureWorkflow();
     config.useLogger(new ConsoleLogger());
     config.usePersistence(persistence);
     let host = config.getHost();
     jasmine.DEFAULT_TIMEOUT_INTERVAL = 20000;

     beforeAll(async () => {
        host.registerWorkflow(Data_Workflow);
        await host.start();
        workflowId = await host.startWorkflow("data-workflow", 1, { value1: 2, value2: 3 });
        await spinWait(async () => {
            instance = await persistence.getWorkflowInstance(workflowId);
            return  (instance.status != WorkflowStatus.Runnable);
        });
     });

     afterAll(async () => {
         await host.stop();
     });
    
     it("should be marked as complete", function() {
         expect(instance.status).toBe(WorkflowStatus.Complete);
     });

     it("should have return value of 5", function() {
         expect(instance.data.value3).toBe(5);
     });

 });
